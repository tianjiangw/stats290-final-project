#' pws data for 290 final project
#'
#' @format a large list (3560 elements, 10.3Mb):
#' \describe{
#'   \item{}{}
#'   \item{}{}
#'   ...
#' }
#' @source \url{http://www.stanford.edu/}

"pws"
